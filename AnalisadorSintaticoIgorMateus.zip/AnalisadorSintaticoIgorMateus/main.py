from sintatico import sintatico
from lexico import lexico
import sys

lexico(False, sys.argv[1], "0")
sintatico()